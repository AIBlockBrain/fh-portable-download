@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\start.ps1"
if errorlevel 1 (
    echo.
    echo [ERROR] Start failed. Opening log...
    notepad "logs\start.log" 2>nul
    pause
) else (
    echo.
    echo [OK] Started. This window will close in 10s.
    timeout /t 10 >nul
)
