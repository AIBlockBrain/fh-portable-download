@echo off
chcp 65001 >nul
title 家庭健康 - 启动
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\start.ps1"
if errorlevel 1 (
    echo.
    echo ============================================
    echo  启动失败！按任意键查看错误日志
    echo ============================================
    pause >nul
    notepad "logs\start.log" 2>nul
) else (
    echo.
    echo ============================================
    echo  启动成功！可以关闭这个窗口
    echo ============================================
    timeout /t 10 >nul
)
