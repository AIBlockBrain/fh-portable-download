@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\upgrade.ps1"
echo.
echo [OK] Upgrade finished.
pause
