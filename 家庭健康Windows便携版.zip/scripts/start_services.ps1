﻿# scripts/start_services.ps1 — 启动 7 个进程 + 2 条隧道 + sync 循环

. "$PSScriptRoot\_common.ps1"

Ensure-Dir $LOGS
Ensure-Dir $PIDS

# ========== 1) PostgreSQL ==========
$pgCtl = Join-Path $PG_BIN "pg_ctl.exe"
$pgLog = Join-Path $LOGS "postgres.log"
& $pgCtl -D $PG_DATA -l $pgLog start -w -t 30 2>&1 | Out-Null
Wait-Port -Port $PORT_PG -TimeoutSec 30 -Name "PostgreSQL" | Out-Null
# PG 自己进程, 写 PID
$pgPid = Get-Content (Join-Path $PG_DATA "postmaster.pid") | Select-Object -First 1
Save-Pid -Name "postgres" -ProcessId ([int]$pgPid)

# ========== 2) Redis ==========
$redisExe = Join-Path $REDIS_HOME "redis-server.exe"
Ensure-Dir $REDIS_DATA
$redisConf = Join-Path $REDIS_DATA "redis.conf"
if (-not (Test-Path $redisConf)) {
@"
bind 127.0.0.1
port $PORT_REDIS
dir $($REDIS_DATA -replace '\\', '/')
save 60 1
appendonly yes
appendfsync everysec
"@ | Set-Content -Path $redisConf -Encoding ascii
}
Start-Background -Name "redis" -Exe $redisExe -Args @($redisConf) -WorkDir $REDIS_HOME | Out-Null
Wait-Port -Port $PORT_REDIS -TimeoutSec 15 -Name "Redis" | Out-Null

# ========== 3) Qdrant ==========
$qdExe = Join-Path $QDRANT_HOME "qdrant.exe"
Ensure-Dir $QDRANT_DATA
$qdConfig = Join-Path $QDRANT_DATA "config.yaml"
if (-not (Test-Path $qdConfig)) {
@"
service:
  host: 127.0.0.1
  http_port: $PORT_QDRANT
  grpc_port: $($PORT_QDRANT + 1)
storage:
  storage_path: $($QDRANT_DATA -replace '\\', '/')/storage
  snapshots_path: $($QDRANT_DATA -replace '\\', '/')/snapshots
"@ | Set-Content -Path $qdConfig -Encoding ascii
}
$qdEnv = @{ "QDRANT__SERVICE__HTTP_PORT" = "$PORT_QDRANT"; "QDRANT__SERVICE__HOST" = "127.0.0.1" }
Start-Background -Name "qdrant" -Exe $qdExe -Args @("--config-path", $qdConfig) -WorkDir $QDRANT_HOME -EnvVars $qdEnv | Out-Null
Wait-Port -Port $PORT_QDRANT -TimeoutSec 20 -Name "Qdrant" | Out-Null

# ========== 4) FastAPI Backend (uvicorn) ==========
$backendEnv = @{
    "PYTHONUNBUFFERED" = "1"
    "PYTHONIOENCODING" = "utf-8"
}
Start-Background -Name "backend" `
    -Exe $PY_EXE `
    -Args @("-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", "$PORT_API") `
    -WorkDir (Join-Path $REPO "backend") `
    -EnvVars $backendEnv | Out-Null
Wait-Port -Port $PORT_API -TimeoutSec 30 -Name "FastAPI" | Out-Null

# ========== 5) Celery Worker ==========
Start-Background -Name "celery-worker" `
    -Exe $PY_EXE `
    -Args @("-m", "celery", "-A", "app.tasks.celery_app", "worker", "--loglevel=info", "-P", "solo") `
    -WorkDir (Join-Path $REPO "backend") `
    -EnvVars $backendEnv | Out-Null

# ========== 6) Celery Beat ==========
Start-Background -Name "celery-beat" `
    -Exe $PY_EXE `
    -Args @("-m", "celery", "-A", "app.tasks.celery_app", "beat", "--loglevel=info") `
    -WorkDir (Join-Path $REPO "backend") `
    -EnvVars $backendEnv | Out-Null

# ========== 7) Flet 管理后台 (Web 模式) ==========
$adminEnv = @{
    "FLET_WEB" = "1"
    "FLET_HOST" = "127.0.0.1"
    "FLET_PORT" = "$PORT_ADMIN"
    "API_BASE" = "http://127.0.0.1:$PORT_API/api"
    "PYTHONUNBUFFERED" = "1"
    "PYTHONIOENCODING" = "utf-8"
}
Start-Background -Name "admin" `
    -Exe $PY_EXE `
    -Args @("main.py") `
    -WorkDir (Join-Path $REPO "admin_panel") `
    -EnvVars $adminEnv | Out-Null
Wait-Port -Port $PORT_ADMIN -TimeoutSec 30 -Name "Flet Admin" | Out-Null

# ========== 8) cloudflared 双隧道 + 推 URL 到 Pages ==========
Log "启动 cloudflared 双隧道..."
& powershell -NoProfile -ExecutionPolicy Bypass -File "$PSScriptRoot\start_tunnels.ps1"

# ========== 9) 启动 sync 循环 (每 3 分钟 git pull) ==========
Log "启动 sync 循环 (每 3 分钟检查 GitHub)"
Start-Background -Name "sync-loop" `
    -Exe "powershell.exe" `
    -Args @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "$PSScriptRoot\sync_loop.ps1") `
    -WorkDir $ROOT | Out-Null

Ok "===== 所有服务已启动 ====="
Write-Host ""
Write-Host "  本机:" -ForegroundColor Cyan
Write-Host "    FastAPI         http://127.0.0.1:$PORT_API/docs"
Write-Host "    Flet 管理后台   http://127.0.0.1:$PORT_ADMIN"
Write-Host ""
Write-Host "  外网 (Cloudflare Pages):" -ForegroundColor Cyan
Write-Host "    H5 用户端       https://mingyichinah5.pages.dev"
Write-Host "    管理后台        https://mingyichinaadmin.pages.dev"
Write-Host ""
