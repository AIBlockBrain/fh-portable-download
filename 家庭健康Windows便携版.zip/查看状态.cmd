@echo off
chcp 65001 >nul
title 家庭健康 - 查看状态
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\status.ps1"
echo.
pause
