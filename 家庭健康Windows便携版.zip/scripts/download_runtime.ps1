﻿# scripts/download_runtime.ps1 — 下载所有 portable 二进制
# 已下载的不重复下；网络中断断点续传

. "$PSScriptRoot\_common.ps1"

Ensure-Dir $RUNTIME
$tmp = Join-Path $RUNTIME "_downloads"
Ensure-Dir $tmp

function Download {
    param([string]$Url, [string]$Out)
    if (Test-Path $Out) {
        Log "已存在, 跳过下载: $(Split-Path -Leaf $Out)"
        return
    }
    Log "下载: $Url"
    $partial = "$Out.partial"
    try {
        Invoke-WebRequest -Uri $Url -OutFile $partial -UseBasicParsing -TimeoutSec 600
        Move-Item -Path $partial -Destination $Out -Force
        Ok "下载完成: $(Split-Path -Leaf $Out)"
    } catch {
        Fail "下载失败 $Url`n$_"
        if (Test-Path $partial) { Remove-Item $partial -Force }
        throw
    }
}

function Expand-To {
    param([string]$Zip, [string]$Dest, [string]$StripWrapperDir = "")
    if (Test-Path $Dest) {
        Log "已解压, 跳过: $Dest"
        return
    }
    Log "解压 $(Split-Path -Leaf $Zip) -> $Dest"
    $stage = Join-Path $tmp ("stage_" + [Guid]::NewGuid().ToString("N"))
    Ensure-Dir $stage
    Expand-Archive -Path $Zip -DestinationPath $stage -Force
    # 处理嵌套一层目录的情况 (postgresql/pgsql/bin/...)
    $entries = Get-ChildItem $stage
    if ($entries.Count -eq 1 -and $entries[0].PSIsContainer) {
        Move-Item -Path $entries[0].FullName -Destination $Dest -Force
    } else {
        Move-Item -Path $stage -Destination $Dest -Force
    }
    Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue
}

# ========== 1) Python 3.13 embeddable ==========
$pyZip = Join-Path $tmp "python-embed.zip"
Download `
    "https://www.python.org/ftp/python/3.13.1/python-3.13.1-embed-amd64.zip" `
    $pyZip
if (-not (Test-Path $PY_EXE)) {
    Ensure-Dir $PY_HOME
    Expand-Archive -Path $pyZip -DestinationPath $PY_HOME -Force
    # 解开 ._pth 文件让 site-packages 生效
    $pth = Get-ChildItem $PY_HOME -Filter "python*._pth" | Select-Object -First 1
    if ($pth) {
        $content = Get-Content $pth.FullName
        $content = $content -replace "^#import site", "import site"
        Set-Content -Path $pth.FullName -Value $content -Encoding ascii
        Ok "Python embeddable site enabled"
    }
    # 装 pip
    $getPip = Join-Path $tmp "get-pip.py"
    Download "https://bootstrap.pypa.io/get-pip.py" $getPip
    & $PY_EXE $getPip --no-warn-script-location 2>&1 | Tee-Object (Join-Path $LOGS "pip-install.log")
    Ok "pip 已装"
}

# ========== 2) PostgreSQL 16 binaries (portable zip) ==========
$pgZip = Join-Path $tmp "postgresql-16.zip"
# 用 EDB 的 binaries-only zip (无安装器)
Download `
    "https://get.enterprisedb.com/postgresql/postgresql-16.4-1-windows-x64-binaries.zip" `
    $pgZip
if (-not (Test-Path $PG_BIN)) {
    Expand-To $pgZip $PG_HOME
    # EDB zip 解出来叫 pgsql/, 内部有 bin/lib/share/...
    Ok "PostgreSQL binaries ready"
}

# ========== 3) Redis Windows portable ==========
$redisZip = Join-Path $tmp "redis-windows.zip"
Download `
    "https://github.com/tporadowski/redis/releases/download/v5.0.14.1/Redis-x64-5.0.14.1.zip" `
    $redisZip
if (-not (Test-Path (Join-Path $REDIS_HOME "redis-server.exe"))) {
    Ensure-Dir $REDIS_HOME
    Expand-Archive -Path $redisZip -DestinationPath $REDIS_HOME -Force
    Ok "Redis ready"
}

# ========== 4) Qdrant ==========
$qdZip = Join-Path $tmp "qdrant.zip"
Download `
    "https://github.com/qdrant/qdrant/releases/download/v1.10.1/qdrant-x86_64-pc-windows-msvc.zip" `
    $qdZip
if (-not (Test-Path (Join-Path $QDRANT_HOME "qdrant.exe"))) {
    Ensure-Dir $QDRANT_HOME
    Expand-Archive -Path $qdZip -DestinationPath $QDRANT_HOME -Force
    Ok "Qdrant ready"
}

# ========== 5) cloudflared (单 exe) ==========
if (-not (Test-Path $CF_EXE)) {
    Ensure-Dir $CF_HOME
    Download `
        "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe" `
        $CF_EXE
    Ok "cloudflared ready"
}

# ========== 6) MinGit (Git portable) ==========
$gitZip = Join-Path $tmp "mingit.zip"
Download `
    "https://github.com/git-for-windows/git/releases/download/v2.46.0.windows.1/MinGit-2.46.0-64-bit.zip" `
    $gitZip
if (-not (Test-Path $GIT_EXE)) {
    Ensure-Dir $GIT_HOME
    Expand-Archive -Path $gitZip -DestinationPath $GIT_HOME -Force
    Ok "Git ready"
}

# ========== 7) Node.js portable (跑 wrangler 用) ==========
$nodeZip = Join-Path $tmp "nodejs.zip"
Download `
    "https://nodejs.org/dist/v20.16.0/node-v20.16.0-win-x64.zip" `
    $nodeZip
if (-not (Test-Path $NODE_EXE)) {
    Ensure-Dir $NODE_HOME
    $stage = Join-Path $tmp "node-stage"
    if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
    Expand-Archive -Path $nodeZip -DestinationPath $stage -Force
    # node zip 里有一层 node-v20.16.0-win-x64/
    $inner = Get-ChildItem $stage | Select-Object -First 1
    Get-ChildItem $inner.FullName | Move-Item -Destination $NODE_HOME -Force
    Remove-Item $stage -Recurse -Force
    Ok "Node.js ready"
}

Ok "所有运行时下载/解压完毕"
