# 🌿 家庭健康系统 · Windows 便携版（无需管理员）

## 这是什么？

把整个后端塞进一个文件夹，**双击 `启动.cmd` 就开机运行**。完全用户态，不需要管理员权限，不安装任何东西，不动注册表（只动 HKCU 当前用户开机自启）。

---

## 适用人群

- 公司电脑没管理员权限 ✅
- 不想装一堆软件污染系统 ✅
- 想随时拷到 U 盘换一台机器跑 ✅

---

## 一次性设置（5 分钟）

### 第 1 步：解压 zip 到任意位置

比如 `D:\家庭健康\` 或 `C:\Users\你\Documents\家庭健康\`。**注意：路径里别有空格**。

解压后目录结构：
```
家庭健康\
├── 启动.cmd          ← 双击它
├── 停止.cmd
├── 升级.cmd
├── 查看状态.cmd
├── 卸载.cmd
├── README.md         ← 你正在看这个
└── scripts\          ← PowerShell 脚本（别动）
```

### 第 2 步：把 Mac 上的机密文件拷过来

**只需要 1 个文件**：

从 Mac 上 `/Users/will/Documents/家庭健康系统HermesV66/backend/.env` 复制到：
```
家庭健康\secrets\backend.env       ← 注意改名: .env -> backend.env (去掉前面的点)
```

（名医模块复用 backend/.env 里的 LLM_API_KEY，不需要单独的 名医.env）

> 这个文件里有 LLM API KEY 等机密，**故意没放 GitHub**。U 盘 / 微信文件传输 / 邮件都可以。

### 第 3 步：双击 `启动.cmd`

第一次启动会自动：
1. 从 GitHub 拉代码
2. 从官方源下载 portable Python / PostgreSQL / Redis / Qdrant / cloudflared / Git / Node.js（共约 350 MB，下载一次永久缓存）
3. 初始化数据库
4. pip 安装依赖
5. 跑 alembic 数据库迁移
6. 起 7 个进程（PG / Redis / Qdrant / FastAPI / Celery worker / Celery beat / Flet 管理后台）
7. 起 2 条 cloudflared 隧道并把 URL 推到 Cloudflare Pages

**首次启动会让你登录 Cloudflare 一次（浏览器自动弹出）**，授权后永久缓存。

完成后，浏览器访问：
- 用户端：https://mingyichinah5.pages.dev
- 管理后台：https://mingyichinaadmin.pages.dev

---

## 日常使用

| 想做的事 | 双击哪个 |
|---|---|
| 启动（开机后） | `启动.cmd` |
| 停止所有服务 | `停止.cmd` |
| Mac 改了代码，更新 | `升级.cmd`（git pull + 重启服务）|
| 看现在跑得怎么样 | `查看状态.cmd` |
| 不想用了，清理 | `卸载.cmd`（只删开机自启注册项；数据/代码保留）|

---

## 自动重启 / 开机自启

`启动.cmd` 首次跑完后会**自动在 HKCU\Run 注册开机启动**（用户态，不需要管理员）。下次开机进入桌面后，服务会在 15~30 秒内自动起来。

如果你想**关闭开机自启**：双击 `卸载.cmd`。

---

## 自动同步代码（每 3 分钟）

启动后会有一个后台 PowerShell 进程每 3 分钟 `git pull` 一次。Mac 那边 push 后，最多 3 分钟内 Windows 自动拉代码、自动重启相关服务。

---

## 排错

### Q：双击 `启动.cmd` 一闪而过怎么办？
按住 Shift + 右键 → 用 PowerShell 打开当前目录 → 输入 `.\启动.cmd` 看完整报错。

### Q：下载 350 MB 卡住怎么办？
- 检查公司网络是否能访问 github.com、python.org、cloudflare.com
- 实在不行：把 zip 拷回家用家里网络跑一次 `启动.cmd`，让它下完所有 `runtime\` 文件，再整个目录拷回公司

### Q：端口被占了？
默认用 5433（PG，避开系统装的 5432）/ 6380（Redis）/ 6334（Qdrant）/ 8000（后端）/ 8550（Flet 后台）。如果还冲突，看 `查看状态.cmd` 里的端口列表，改 `scripts\_ports.ps1`。

### Q：U 盘换电脑？
**完全可以**。把整个文件夹拷到新电脑双击 `启动.cmd` 即可。但数据库数据也跟着走（在 `data\postgres\`）。

---

## 内部结构

```
家庭健康\
├── 启动.cmd / 停止.cmd / ...
├── README.md
├── scripts\
│   ├── _common.ps1                公共函数
│   ├── _ports.ps1                 端口配置
│   ├── start.ps1                  启动主流程
│   ├── stop.ps1                   停止主流程
│   ├── upgrade.ps1                git pull + 重启
│   ├── status.ps1                 状态检查
│   ├── uninstall.ps1              清理 HKCU\Run
│   ├── bootstrap.ps1              首次配置
│   ├── download_runtime.ps1       下载 portable 二进制
│   ├── start_services.ps1         起所有进程
│   ├── stop_services.ps1          杀所有进程
│   ├── start_tunnels.ps1          起两条 cloudflared
│   ├── push_tunnel_url.ps1        推 URL 到 Pages
│   └── sync_loop.ps1              每 3 分钟 git pull
├── runtime\                       (首次启动自动下载)
│   ├── python\                    Python 3.13 embeddable + pip
│   ├── postgresql\                PostgreSQL 16 binaries
│   ├── redis\                     Redis Windows portable
│   ├── qdrant\                    qdrant.exe
│   ├── cloudflared\               cloudflared.exe
│   ├── git\                       PortableGit
│   └── nodejs\                    Node.js portable (跑 wrangler 用)
├── data\                          (首次启动自动创建)
│   ├── postgres\                  PG 数据
│   ├── redis\                     Redis 持久化
│   └── qdrant\                    向量库
├── logs\                          所有日志
├── pids\                          进程 PID 文件
├── secrets\                       (你自己放)
│   ├── backend.env
│   └── 名医.env
└── repo\                          (首次启动 git clone)
    └── family-health-system\
```
