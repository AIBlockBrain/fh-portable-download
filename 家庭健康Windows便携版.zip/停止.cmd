@echo off
chcp 65001 >nul
title 家庭健康 - 停止
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\stop.ps1"
echo.
echo 已停止。按任意键关闭...
pause >nul
