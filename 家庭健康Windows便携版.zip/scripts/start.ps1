﻿# scripts/start.ps1 — 启动主入口 (启动.cmd 调用这个)

. "$PSScriptRoot\_common.ps1"

# 重置 start.log
Ensure-Dir $LOGS
Set-Content -Path (Join-Path $LOGS "start.log") -Value "" -Encoding utf8

Log "==========================================="
Log "  家庭健康系统 · Windows 便携版 启动"
Log "==========================================="

# 自检: 是否已 bootstrap?
if (-not (Is-Bootstrapped)) {
    Log "首次启动, 进入 bootstrap 流程"
    & "$PSScriptRoot\bootstrap.ps1"
    if ($LASTEXITCODE -ne 0) {
        Fail "bootstrap 失败, 看 logs\start.log"
        exit 1
    }
}

# 杀掉残留进程 (避免端口冲突)
Log "清理旧进程..."
& "$PSScriptRoot\stop_services.ps1"
Start-Sleep -Seconds 2

# 启动所有服务
& "$PSScriptRoot\start_services.ps1"
