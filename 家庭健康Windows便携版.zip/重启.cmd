@echo off
chcp 65001 >nul
title 家庭健康 - 重启
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\stop.ps1"
timeout /t 3 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\start.ps1"
echo.
echo 重启完成。按任意键关闭...
pause >nul
