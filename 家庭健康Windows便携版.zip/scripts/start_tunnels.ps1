# scripts/start_tunnels.ps1 — 双 cloudflared 隧道 + 自动推 Pages secret
. "$PSScriptRoot\_common.ps1"

# 杀旧 cloudflared (按 PID 文件)
Kill-ByPidFile -Name "tunnel-h5"
Kill-ByPidFile -Name "tunnel-admin"

function Start-Tunnel {
    param([string]$Name, [int]$LocalPort, [string]$Project)
    $logFile = Join-Path $LOGS "$Name.log"
    "" | Set-Content $logFile -Encoding utf8
    $p = Start-Process -FilePath $CF_EXE `
        -ArgumentList "tunnel", "--no-autoupdate", "--url", "http://127.0.0.1:$LocalPort", "--logfile", $logFile `
        -WindowStyle Hidden -PassThru
    Save-Pid -Name $Name -ProcessId $p.Id
    Ok "$Name cloudflared pid $($p.Id) -> :$LocalPort"

    # 等 trycloudflare URL
    $url = ""
    for ($i = 0; $i -lt 45; $i++) {
        Start-Sleep -Seconds 1
        $c = Get-Content $logFile -Raw -ErrorAction SilentlyContinue
        if ($c -and $c -match "https://([a-z0-9-]+)\.trycloudflare\.com") {
            $url = "https://$($Matches[1]).trycloudflare.com"
            break
        }
    }
    if (-not $url) { Fail "$Name 没拿到 URL"; return $null }
    Ok "$Name URL: $url"

    # 写到本地缓存
    Set-Content -Path (Join-Path $ROOT "data\$Name.url") -Value $url -Encoding ascii -NoNewline

    # 推到 Pages secret (后台异步, 不阻塞)
    if ($Project) {
        $envH = @{
            "WRANGLER_HOME" = (Join-Path $ROOT "data\wrangler")
            "NPM_CONFIG_CACHE" = (Join-Path $ROOT "data\npm-cache")
            "PATH" = "$NODE_HOME;$env:PATH"
        }
        Ensure-Dir $envH["WRANGLER_HOME"]
        Ensure-Dir $envH["NPM_CONFIG_CACHE"]

        $pushScript = @"
`$ErrorActionPreference='Continue'
`$env:WRANGLER_HOME='$($envH["WRANGLER_HOME"])'
`$env:NPM_CONFIG_CACHE='$($envH["NPM_CONFIG_CACHE"])'
`$env:PATH='$NODE_HOME;' + `$env:PATH
`$tmp = [System.IO.Path]::GetTempFileName()
Set-Content `$tmp -Value '$url' -NoNewline -Encoding ascii
try {
    # 用 npx 调 wrangler. 第一次会弹浏览器 OAuth, 之后自动
    cmd /c "type `"`$tmp`" | `"$NPX_CMD`" --yes wrangler@latest pages secret put TUNNEL_URL --project-name=$Project" 2>&1 |
        Out-File (Join-Path '$LOGS' '$Name-push.log') -Encoding utf8
} finally { Remove-Item `$tmp -Force -ErrorAction SilentlyContinue }
"@
        $pushFile = Join-Path $ROOT "data\push-$Name.ps1"
        Set-Content $pushFile -Value $pushScript -Encoding utf8
        Start-Process powershell -ArgumentList "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $pushFile -WindowStyle Hidden
        Log "  -> 后台推送中 (首次会弹浏览器登录 Cloudflare): $Project"
    }

    return $url
}

$urlH5    = Start-Tunnel -Name "tunnel-h5"    -LocalPort $PORT_API   -Project "mingyichinah5"
$urlAdmin = Start-Tunnel -Name "tunnel-admin" -LocalPort $PORT_ADMIN -Project "mingyichinaadmin"

Ok "隧道全部就绪"
