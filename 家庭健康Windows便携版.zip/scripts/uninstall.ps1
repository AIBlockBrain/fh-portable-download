﻿# scripts/uninstall.ps1 — 取消开机自启 (HKCU\Run)
. "$PSScriptRoot\_common.ps1"

$regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
try {
    Remove-ItemProperty -Path $regPath -Name "FamilyHealth" -ErrorAction Stop
    Ok "已取消开机自启 (HKCU\Run\FamilyHealth)"
} catch {
    Warn "HKCU\Run 里没有 FamilyHealth 项, 跳过"
}

Write-Host ""
Write-Host "数据/代码/运行时都保留在: $ROOT" -ForegroundColor Cyan
Write-Host "如果要彻底删除, 直接删整个文件夹即可。" -ForegroundColor Cyan
