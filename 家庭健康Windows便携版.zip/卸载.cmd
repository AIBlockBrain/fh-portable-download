@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo This will stop all services and remove auto-start from HKCU\Run.
echo Data and code will NOT be deleted.
echo.
choice /C YN /M "Confirm uninstall"
if errorlevel 2 goto :end
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\stop.ps1"
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\uninstall.ps1"
:end
pause
