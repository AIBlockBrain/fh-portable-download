# scripts/bootstrap.ps1 — 首次设置 (下载+initdb+pip+alembic+HKCU Run)

. "$PSScriptRoot\_common.ps1"

Log "===== bootstrap 开始 (首次设置) ====="

# ---- 1) 检查机密文件 ----
$beEnv = Join-Path $SECRETS "backend.env"
$myEnv = Join-Path $SECRETS "名医.env"
if (-not (Test-Path $beEnv)) {
    Fail "缺少 $beEnv"
    Write-Host ""
    Write-Host "请把 Mac 上的 backend\.env 复制到这个位置:" -ForegroundColor Yellow
    Write-Host "  $beEnv" -ForegroundColor Yellow
    Write-Host "然后重新双击 启动.cmd" -ForegroundColor Yellow
    exit 1
}
if (-not (Test-Path $myEnv)) {
    Fail "缺少 $myEnv"
    Write-Host ""
    Write-Host "请把 Mac 上的 名医\.env 复制到这个位置:" -ForegroundColor Yellow
    Write-Host "  $myEnv" -ForegroundColor Yellow
    Write-Host "然后重新双击 启动.cmd" -ForegroundColor Yellow
    exit 1
}
Ok "secrets OK"

# ---- 2) 下载所有运行时 ----
Log "下载 portable 运行时 (首次约 350MB, 后续不再下)"
& "$PSScriptRoot\download_runtime.ps1"
if ($LASTEXITCODE -ne 0) { Fail "下载失败"; exit 1 }

# ---- 3) git clone 代码 ----
Ensure-Dir (Split-Path $REPO -Parent)
if (-not (Test-Path $REPO)) {
    Log "git clone..."
    & $GIT_EXE clone --depth 1 -b $GIT_BRANCH $GIT_REPO $REPO 2>&1 | Tee-Object (Join-Path $LOGS "git-clone.log")
    if ($LASTEXITCODE -ne 0) { Fail "git clone 失败"; exit 1 }
    Ok "代码已克隆"
} else {
    Ok "代码已存在, 跳过 clone"
}

# 把 secrets 链接到 repo 内对应位置
Copy-Item -Path $beEnv -Destination (Join-Path $REPO "backend\.env") -Force
Copy-Item -Path $myEnv -Destination (Join-Path $REPO "名医\.env") -Force
Ok ".env 已就位"

# ---- 4) initdb (首次) ----
Ensure-Dir $DATA
if (-not (Test-Path (Join-Path $PG_DATA "PG_VERSION"))) {
    Log "初始化 PostgreSQL data dir..."
    Ensure-Dir $PG_DATA
    $pwFile = Join-Path $env:TEMP "pg_init_pw.txt"
    Set-Content -Path $pwFile -Value "postgres" -Encoding ascii -NoNewline
    & (Join-Path $PG_BIN "initdb.exe") `
        -D $PG_DATA `
        -U postgres `
        --pwfile=$pwFile `
        -E UTF8 `
        --locale=C 2>&1 | Tee-Object (Join-Path $LOGS "initdb.log")
    Remove-Item $pwFile -Force -ErrorAction SilentlyContinue
    if ($LASTEXITCODE -ne 0) { Fail "initdb 失败"; exit 1 }

    # 改端口, 只听 127.0.0.1
    $confPath = Join-Path $PG_DATA "postgresql.conf"
    Add-Content -Path $confPath -Value "`nport = $PORT_PG" -Encoding utf8
    Add-Content -Path $confPath -Value "listen_addresses = '127.0.0.1'" -Encoding utf8
    Add-Content -Path $confPath -Value "unix_socket_directories = ''" -Encoding utf8  # Windows 无 unix socket
    Ok "PG initdb 完成 (port $PORT_PG)"
}

# ---- 5) 启动 PG (临时, 为了建库) ----
$pgCtl = Join-Path $PG_BIN "pg_ctl.exe"
$pgLog = Join-Path $LOGS "postgres.log"
Log "临时启动 PG 以建库..."
& $pgCtl -D $PG_DATA -l $pgLog start -w -t 30 2>&1 | Out-Null
if (-not (Wait-Port -Port $PORT_PG -TimeoutSec 30 -Name "PostgreSQL")) { exit 1 }

# ---- 6) 建 DB / USER ----
$env:PGPASSWORD = "postgres"
$psql = Join-Path $PG_BIN "psql.exe"

$createUserSql = "SELECT 1 FROM pg_roles WHERE rolname='$DB_USER'"
$exists = & $psql -h 127.0.0.1 -p $PORT_PG -U postgres -tA -c $createUserSql 2>$null
if ($exists -ne "1") {
    & $psql -h 127.0.0.1 -p $PORT_PG -U postgres -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASS';" 2>&1 | Out-Null
    Ok "PG user $DB_USER 已创建"
}

$dbExists = & $psql -h 127.0.0.1 -p $PORT_PG -U postgres -tA -c "SELECT 1 FROM pg_database WHERE datname='$DB_NAME'" 2>$null
if ($dbExists -ne "1") {
    & $psql -h 127.0.0.1 -p $PORT_PG -U postgres -c "CREATE DATABASE $DB_NAME OWNER $DB_USER ENCODING 'UTF8' LC_COLLATE 'C' LC_CTYPE 'C' TEMPLATE template0;" 2>&1 | Out-Null
    Ok "PG database $DB_NAME 已创建"
}

# ---- 7) 写 backend/.env 里的 DATABASE_URL (覆盖, 指向本地 PG) ----
$beEnvFile = Join-Path $REPO "backend\.env"
$envContent = Get-Content $beEnvFile -Raw -Encoding utf8
$dbUrl = "postgresql+asyncpg://${DB_USER}:${DB_PASS}@127.0.0.1:${PORT_PG}/${DB_NAME}"
$redisUrl = "redis://127.0.0.1:${PORT_REDIS}/0"
$qdrantUrl = "http://127.0.0.1:${PORT_QDRANT}"

function Set-EnvKey {
    param([string]$Content, [string]$Key, [string]$Value)
    if ($Content -match "(?m)^\s*$Key\s*=") {
        return ($Content -replace "(?m)^\s*$Key\s*=.*$", "$Key=$Value")
    } else {
        return $Content.TrimEnd() + "`n$Key=$Value`n"
    }
}
$envContent = Set-EnvKey $envContent "DATABASE_URL" $dbUrl
$envContent = Set-EnvKey $envContent "REDIS_URL"    $redisUrl
$envContent = Set-EnvKey $envContent "QDRANT_URL"   $qdrantUrl
Set-Content -Path $beEnvFile -Value $envContent -Encoding utf8 -NoNewline
Ok "backend/.env DATABASE_URL/REDIS_URL/QDRANT_URL 已重写为本机端口"

# ---- 8) pip install ----
Log "pip install backend deps..."
$pip = $PY_EXE
& $pip -m pip install --upgrade pip 2>&1 | Out-Null
& $pip -m pip install -r (Join-Path $REPO "backend\requirements.txt") 2>&1 | Tee-Object (Join-Path $LOGS "pip-backend.log") | Out-Null
& $pip -m pip install -r (Join-Path $REPO "名医\requirements.txt") 2>&1 | Tee-Object (Join-Path $LOGS "pip-mingyi.log") | Out-Null
& $pip -m pip install -r (Join-Path $REPO "admin_panel\requirements.txt") 2>&1 | Tee-Object (Join-Path $LOGS "pip-admin.log") | Out-Null
Ok "pip install 完成"

# ---- 9) alembic upgrade head ----
Log "alembic upgrade head..."
Push-Location (Join-Path $REPO "backend")
try {
    & $PY_EXE -m alembic upgrade head 2>&1 | Tee-Object (Join-Path $LOGS "alembic.log")
    Ok "alembic upgrade 完成"
} catch {
    Fail "alembic 失败: $_"
    exit 1
} finally {
    Pop-Location
}

# ---- 10) 停掉临时 PG (start.ps1 会再起) ----
& $pgCtl -D $PG_DATA stop -m fast 2>&1 | Out-Null
Ok "临时 PG 已停"

# ---- 11) 注册 HKCU Run 开机自启 ----
$startCmd = Join-Path $ROOT "启动.cmd"
$regCmd = "`"$startCmd`""
$regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
New-ItemProperty -Path $regPath -Name "FamilyHealth" -Value $regCmd -PropertyType String -Force | Out-Null
Ok "HKCU\Run 已注册 (下次开机自动启动)"

# ---- 12) 标记已 bootstrap ----
Set-Content -Path (Join-Path $ROOT ".bootstrapped") -Value (Get-Date).ToString("o") -Encoding ascii

Ok "===== bootstrap 完成 ====="
