﻿# scripts/sync_loop.ps1 — 后台每 3 分钟 git pull 一次
. "$PSScriptRoot\_common.ps1"

while ($true) {
    try {
        Push-Location $REPO
        $before = (& $GIT_EXE rev-parse HEAD 2>$null).Trim()
        & $GIT_EXE fetch origin $GIT_BRANCH 2>&1 | Out-Null
        $remote = (& $GIT_EXE rev-parse "origin/$GIT_BRANCH" 2>$null).Trim()
        Pop-Location

        if ($before -ne $remote -and $remote) {
            Log "sync-loop: 检测到新提交, 触发 upgrade"
            & powershell -NoProfile -ExecutionPolicy Bypass -File "$PSScriptRoot\upgrade.ps1"
        }
    } catch {
        Warn "sync-loop 出错: $_"
    }
    Start-Sleep -Seconds 180
}
