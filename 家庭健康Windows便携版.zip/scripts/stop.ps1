﻿# scripts/stop.ps1 — 停止入口
. "$PSScriptRoot\_common.ps1"
Log "停止所有服务..."
& "$PSScriptRoot\stop_services.ps1"
Ok "已全部停止"
