# scripts/upgrade.ps1 — git pull + 自动重启
. "$PSScriptRoot\_common.ps1"

if (-not (Test-Path $REPO)) {
    Fail "repo 不存在, 请先双击 启动.cmd 完成首次设置"
    exit 1
}

Log "git fetch + pull..."
Push-Location $REPO
try {
    $before = (& $GIT_EXE rev-parse HEAD).Trim()
    & $GIT_EXE fetch origin $GIT_BRANCH 2>&1 | Out-Null
    & $GIT_EXE reset --hard "origin/$GIT_BRANCH" 2>&1 | Out-Null
    $after = (& $GIT_EXE rev-parse HEAD).Trim()
    if ($before -eq $after) {
        Ok "已是最新, 无需重启"
        return
    }
    Log "更新: $before -> $after"

    # 同步 secrets 到 repo (防止 reset 丢失)
    Copy-Item -Path (Join-Path $SECRETS "backend.env") -Destination (Join-Path $REPO "backend\.env") -Force
    Copy-Item -Path (Join-Path $SECRETS "名医.env")  -Destination (Join-Path $REPO "名医\.env")  -Force

    # 如果 requirements 改了, 重装
    $reqChanged = (& $GIT_EXE diff --name-only $before $after) -match "requirements\.txt"
    if ($reqChanged) {
        Log "requirements.txt 变了, 重装 pip 依赖"
        & $PY_EXE -m pip install -r (Join-Path $REPO "backend\requirements.txt") 2>&1 | Out-Null
        & $PY_EXE -m pip install -r (Join-Path $REPO "admin_panel\requirements.txt") 2>&1 | Out-Null
        & $PY_EXE -m pip install -r (Join-Path $REPO "名医\requirements.txt") 2>&1 | Out-Null
    }

    # 如果有新 alembic migration, 跑
    $alembicChanged = (& $GIT_EXE diff --name-only $before $after) -match "backend/migrations/"
    if ($alembicChanged) {
        Log "alembic 变了, 跑 upgrade head"
        Push-Location (Join-Path $REPO "backend")
        & $PY_EXE -m alembic upgrade head 2>&1 | Tee-Object (Join-Path $LOGS "alembic-upgrade.log")
        Pop-Location
    }

    Ok "代码更新完成, 重启服务..."
} finally {
    Pop-Location
}

& "$PSScriptRoot\stop_services.ps1"
Start-Sleep -Seconds 2
& "$PSScriptRoot\start_services.ps1"
