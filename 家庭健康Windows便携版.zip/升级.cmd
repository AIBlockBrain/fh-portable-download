@echo off
chcp 65001 >nul
title 家庭健康 - 升级
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\upgrade.ps1"
echo.
echo 升级完成。按任意键关闭...
pause >nul
