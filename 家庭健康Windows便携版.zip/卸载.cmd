@echo off
chcp 65001 >nul
title 家庭健康 - 卸载
cd /d "%~dp0"
echo.
echo 这会做以下事情:
echo   1) 停止所有服务
echo   2) 取消开机自启 (HKCU\Run)
echo.
echo 不会删除: 代码、数据库、运行时（你可以手动删整个文件夹）
echo.
choice /C YN /M "确定要卸载吗"
if errorlevel 2 goto :end
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\stop.ps1"
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\uninstall.ps1"
:end
pause
