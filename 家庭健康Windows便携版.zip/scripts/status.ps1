# scripts/status.ps1 — 查看所有服务状态
. "$PSScriptRoot\_common.ps1"

Write-Host ""
Write-Host "========== 家庭健康系统 · 状态 ==========" -ForegroundColor Cyan

Write-Host ""
Write-Host "[端口监听]" -ForegroundColor Yellow
$ports = @{
    "PostgreSQL"   = $PORT_PG
    "Redis"        = $PORT_REDIS
    "Qdrant"       = $PORT_QDRANT
    "FastAPI"      = $PORT_API
    "Flet 后台"    = $PORT_ADMIN
}
foreach ($n in $ports.Keys) {
    $p = $ports[$n]
    if (Test-Port -Port $p) {
        Write-Host ("  [+] {0,-12} :{1}" -f $n, $p) -ForegroundColor Green
    } else {
        Write-Host ("  [-] {0,-12} :{1} 未监听" -f $n, $p) -ForegroundColor Red
    }
}

Write-Host ""
Write-Host "[进程 PID]" -ForegroundColor Yellow
if (Test-Path $PIDS) {
    Get-ChildItem $PIDS -Filter "*.pid" | ForEach-Object {
        $name = $_.BaseName
        $pidVal = (Get-Content $_.FullName -Raw).Trim()
        $proc = Get-Process -Id $pidVal -ErrorAction SilentlyContinue
        if ($proc) {
            Write-Host ("  [+] {0,-15} pid {1}" -f $name, $pidVal) -ForegroundColor Green
        } else {
            Write-Host ("  [-] {0,-15} pid {1} (已退出)" -f $name, $pidVal) -ForegroundColor Red
        }
    }
} else {
    Write-Host "  (无 PID 文件 - 服务可能未启动)" -ForegroundColor Gray
}

Write-Host ""
Write-Host "[隧道 URL]" -ForegroundColor Yellow
$urlH5    = Join-Path $ROOT "data\tunnel-h5.url"
$urlAdmin = Join-Path $ROOT "data\tunnel-admin.url"
if (Test-Path $urlH5)    { Write-Host "  H5    : $((Get-Content $urlH5 -Raw).Trim())  ->  https://mingyichinah5.pages.dev" }
if (Test-Path $urlAdmin) { Write-Host "  Admin : $((Get-Content $urlAdmin -Raw).Trim())  ->  https://mingyichinaadmin.pages.dev" }

Write-Host ""
Write-Host "[HTTP 健康]" -ForegroundColor Yellow
try {
    $r = Invoke-WebRequest -Uri "http://127.0.0.1:$PORT_API/health" -UseBasicParsing -TimeoutSec 3
    Write-Host "  [+] backend /health  HTTP $($r.StatusCode)" -ForegroundColor Green
} catch {
    Write-Host "  [-] backend /health  失败: $_" -ForegroundColor Red
}
try {
    $r = Invoke-WebRequest -Uri "http://127.0.0.1:$PORT_ADMIN/" -UseBasicParsing -TimeoutSec 3
    Write-Host "  [+] admin /         HTTP $($r.StatusCode)" -ForegroundColor Green
} catch {
    Write-Host "  [-] admin /         失败: $_" -ForegroundColor Red
}

Write-Host ""
Write-Host "[git 状态]" -ForegroundColor Yellow
if (Test-Path $REPO) {
    Push-Location $REPO
    $head = (& $GIT_EXE rev-parse --short HEAD 2>$null).Trim()
    $msg  = (& $GIT_EXE log -1 --pretty=format:"%s" 2>$null).Trim()
    Write-Host "  HEAD: $head  -  $msg"
    Pop-Location
} else {
    Write-Host "  (repo 未克隆)" -ForegroundColor Gray
}

Write-Host ""
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "日志: $LOGS"
Write-Host ""
