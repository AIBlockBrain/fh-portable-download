@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\stop.ps1"
timeout /t 3 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\start.ps1"
echo.
echo [OK] Restarted.
pause
