# scripts/stop_services.ps1 — 杀所有服务进程 (按 PID 文件)
. "$PSScriptRoot\_common.ps1"

$names = @("sync-loop", "tunnel-h5", "tunnel-admin", "admin", "celery-beat", "celery-worker", "backend", "qdrant", "redis")
foreach ($n in $names) {
    Kill-ByPidFile -Name $n
}

# PG 用 pg_ctl 优雅停止
$pgCtl = Join-Path $PG_BIN "pg_ctl.exe"
if (Test-Path $pgCtl) {
    & $pgCtl -D $PG_DATA stop -m fast 2>&1 | Out-Null
    Ok "PostgreSQL stopped"
}
Remove-Item (Join-Path $PIDS "postgres.pid") -Force -ErrorAction SilentlyContinue
