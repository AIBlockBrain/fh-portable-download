﻿# scripts/_common.ps1 — 公共函数 / 路径 / 端口
# 所有脚本都用 dot-source: . "$PSScriptRoot\_common.ps1"

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"  # 加速 Invoke-WebRequest

# ---- 目录 (相对于 zip 解压根目录) ----
$global:ROOT     = (Resolve-Path "$PSScriptRoot\..").Path
$global:RUNTIME  = Join-Path $ROOT "runtime"
$global:DATA     = Join-Path $ROOT "data"
$global:LOGS     = Join-Path $ROOT "logs"
$global:PIDS     = Join-Path $ROOT "pids"
$global:SECRETS  = Join-Path $ROOT "secrets"
$global:REPO     = Join-Path $ROOT "repo\family-health-system"

# 运行时各组件
$global:PY_HOME  = Join-Path $RUNTIME "python"
$global:PY_EXE   = Join-Path $PY_HOME "python.exe"
$global:PG_HOME  = Join-Path $RUNTIME "postgresql"
$global:PG_BIN   = Join-Path $PG_HOME "bin"
$global:PG_DATA  = Join-Path $DATA "postgres"
$global:REDIS_HOME  = Join-Path $RUNTIME "redis"
$global:REDIS_DATA  = Join-Path $DATA "redis"
$global:QDRANT_HOME = Join-Path $RUNTIME "qdrant"
$global:QDRANT_DATA = Join-Path $DATA "qdrant"
$global:CF_HOME  = Join-Path $RUNTIME "cloudflared"
$global:CF_EXE   = Join-Path $CF_HOME "cloudflared.exe"
$global:GIT_HOME = Join-Path $RUNTIME "git"
$global:GIT_EXE  = Join-Path $GIT_HOME "cmd\git.exe"
$global:NODE_HOME = Join-Path $RUNTIME "nodejs"
$global:NODE_EXE  = Join-Path $NODE_HOME "node.exe"
$global:NPX_CMD   = Join-Path $NODE_HOME "npx.cmd"

# ---- 端口 (避开常见系统占用) ----
$global:PORT_PG     = 5433
$global:PORT_REDIS  = 6380
$global:PORT_QDRANT = 6334
$global:PORT_API    = 8000
$global:PORT_ADMIN  = 8550

# ---- 数据库 ----
$global:DB_NAME = "family_health"
$global:DB_USER = "fh_user"
$global:DB_PASS = "fh_local_pass_2026"  # 仅本机, 用户态, 数据库只监听 127.0.0.1

# ---- GitHub 仓 ----
$global:GIT_REPO = "https://github.com/AIBlockBrain/family-health-system.git"
$global:GIT_BRANCH = "main"

# 读取 secrets/github_token.txt, 把 token 注入 https URL (私有仓所需)
# 返回带认证的 URL; 如果 token 文件不存在则返回 $null
function Get-AuthedRepoUrl {
    $tokenFile = Join-Path $SECRETS "github_token.txt"
    if (-not (Test-Path $tokenFile)) { return $null }
    $token = (Get-Content $tokenFile -Raw -Encoding UTF8).Trim()
    if (-not $token) { return $null }
    # https://github.com/...  ->  https://oauth2:TOKEN@github.com/...
    return ($GIT_REPO -replace '^https://', "https://oauth2:$token@")
}

# ---- 日志 ----
function Log {
    param([string]$Msg, [string]$Level = "INFO", [string]$Color = "White")
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$ts] [$Level] $Msg"
    Write-Host $line -ForegroundColor $Color
    New-Item -ItemType Directory -Path $LOGS -Force -ErrorAction SilentlyContinue | Out-Null
    Add-Content -Path (Join-Path $LOGS "start.log") -Value $line -Encoding utf8 -ErrorAction SilentlyContinue
}
function Ok    { param($m) Log $m "OK"    "Green" }
function Warn  { param($m) Log $m "WARN"  "Yellow" }
function Fail  { param($m) Log $m "ERROR" "Red" }

# ---- 工具 ----
function Ensure-Dir { param([string]$P) New-Item -ItemType Directory -Path $P -Force -ErrorAction SilentlyContinue | Out-Null }

function Test-Port {
    param([int]$Port)
    try {
        $c = New-Object System.Net.Sockets.TcpClient
        $c.Connect("127.0.0.1", $Port)
        $c.Close()
        return $true
    } catch { return $false }
}

function Wait-Port {
    param([int]$Port, [int]$TimeoutSec = 30, [string]$Name = "service")
    for ($i = 0; $i -lt $TimeoutSec; $i++) {
        if (Test-Port -Port $Port) { Ok "$Name listening on :$Port"; return $true }
        Start-Sleep -Seconds 1
    }
    Fail "$Name 没在 ${TimeoutSec}s 内启动 (:$Port)"
    return $false
}

function Save-Pid {
    param([string]$Name, [int]$ProcessId)
    Ensure-Dir $PIDS
    Set-Content -Path (Join-Path $PIDS "$Name.pid") -Value $ProcessId -Encoding ascii
}

function Read-Pid {
    param([string]$Name)
    $f = Join-Path $PIDS "$Name.pid"
    if (Test-Path $f) { return [int](Get-Content $f -Raw).Trim() }
    return 0
}

function Kill-ByPidFile {
    param([string]$Name)
    $pidVal = Read-Pid -Name $Name
    if ($pidVal -gt 0) {
        try { Stop-Process -Id $pidVal -Force -ErrorAction Stop; Ok "killed $Name (pid $pidVal)" }
        catch { Warn "$Name (pid $pidVal) already gone" }
        Remove-Item (Join-Path $PIDS "$Name.pid") -Force -ErrorAction SilentlyContinue
    }
}

function Start-Background {
    param(
        [string]$Name,
        [string]$Exe,
        [string[]]$Args,
        [string]$WorkDir,
        [hashtable]$EnvVars
    )
    Ensure-Dir $LOGS
    Ensure-Dir $PIDS
    $stdoutLog = Join-Path $LOGS "$Name.log"
    $stderrLog = Join-Path $LOGS "$Name.err.log"

    # 应用环境变量到当前进程, Start-Process 会继承
    $oldVals = @{}
    if ($EnvVars) {
        foreach ($k in $EnvVars.Keys) {
            $oldVals[$k] = [Environment]::GetEnvironmentVariable($k, "Process")
            [Environment]::SetEnvironmentVariable($k, $EnvVars[$k], "Process")
        }
    }
    try {
        $p = Start-Process -FilePath $Exe -ArgumentList $Args `
            -WorkingDirectory $WorkDir `
            -RedirectStandardOutput $stdoutLog `
            -RedirectStandardError  $stderrLog `
            -WindowStyle Hidden -PassThru
        Save-Pid -Name $Name -ProcessId $p.Id
        Ok "$Name started (pid $($p.Id))"
        return $p
    } finally {
        # 恢复环境变量
        if ($EnvVars) {
            foreach ($k in $EnvVars.Keys) {
                [Environment]::SetEnvironmentVariable($k, $oldVals[$k], "Process")
            }
        }
    }
}

function Load-DotEnv {
    param([string]$Path)
    if (-not (Test-Path $Path)) { return @{} }
    $h = @{}
    Get-Content $Path -Encoding utf8 | ForEach-Object {
        $line = $_.Trim()
        if ($line -eq "" -or $line.StartsWith("#")) { return }
        if ($line -match "^\s*([^=]+?)\s*=\s*(.*?)\s*$") {
            $k = $matches[1].Trim()
            $v = $matches[2].Trim()
            # 去掉两端引号
            if ($v.StartsWith('"') -and $v.EndsWith('"')) { $v = $v.Substring(1, $v.Length - 2) }
            elseif ($v.StartsWith("'") -and $v.EndsWith("'")) { $v = $v.Substring(1, $v.Length - 2) }
            $h[$k] = $v
        }
    }
    return $h
}

function Is-Bootstrapped {
    return (Test-Path $PY_EXE) -and (Test-Path $PG_BIN) -and (Test-Path $REDIS_HOME) `
        -and (Test-Path $QDRANT_HOME) -and (Test-Path $CF_EXE) `
        -and (Test-Path $GIT_EXE) -and (Test-Path $REPO) `
        -and (Test-Path (Join-Path $PG_DATA "PG_VERSION"))
}
